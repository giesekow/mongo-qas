from flask import Flask, redirect, url_for
from .script import main
from .app import create_app